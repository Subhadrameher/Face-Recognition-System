async function api(url, opts) {
  const r = await fetch(url, opts); let d = {};
  try { d = await r.json(); } catch (e) {}
  if (!r.ok) { const err = new Error(d.error || "Request failed"); err.details = d.details; throw err; }
  return d;
}
function toast(msg, ok = true) {
  const el = document.getElementById("msg"); if (!el) return alert(msg);
  el.className = "alert " + (ok ? "alert-success" : "alert-danger"); el.textContent = msg; el.classList.remove("d-none");
}
function drawBoxes(canvas, data) {
  canvas.width = data.width; canvas.height = data.height;
  const c = canvas.getContext("2d"); c.clearRect(0, 0, canvas.width, canvas.height);
  c.lineWidth = Math.max(2, data.width / 300); c.font = `600 ${Math.max(14, data.width / 40)}px Sora, sans-serif`;
  data.faces.forEach(f => {
    const [x, y, w, h] = f.box, col = f.known ? "#34d399" : "#f87171";
    const label = `${f.name} ${(f.similarity * 100).toFixed(1)}%`;
    c.strokeStyle = col; c.strokeRect(x, y, w, h);
    const tw = c.measureText(label).width + 10, th = parseInt(c.font.match(/\d+/)[0]) + 8;
    c.fillStyle = col; c.fillRect(x, Math.max(0, y - th), tw, th);
    c.fillStyle = "#04102b"; c.fillText(label, x + 5, Math.max(th - 6, y - 6));
  });
}
function esc(s) { return String(s ?? "").replace(/[&<>"']/g, m => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m])); }
document.getElementById("menu")?.addEventListener("click", () => document.querySelector(".side").classList.toggle("open"));
